from django.urls import path
from . import views

urlpatterns = [
    path('search/', views.search_doctors, name='search_doctors'),
    path('get-locations/', views.get_locations, name='get_locations'),
    path('get-specializations/', views.get_specializations, name='get_specializations'),
    path('list/', views.list_doctors, name='list_doctors'),
    path('book/<int:doctor_id>/', views.book_timeslot, name='book_timeslot'),
    path('booking-success/', views.booking_success, name='booking_success'),
]