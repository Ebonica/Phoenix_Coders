from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Doctor, Specialization, Location, TimeSlot, Booking
from django.db.models import Q
from django.contrib.auth.decorators import login_required

def search_doctors(request):
    return render(request, 'doctor_finder/search.html')

def get_locations(request):
    query = request.GET.get('query', '')
    locations = Location.objects.filter(name__istartswith=query).values_list('name', flat=True)
    return JsonResponse(list(locations), safe=False)

def get_specializations(request):
    query = request.GET.get('query', '')
    specializations = Specialization.objects.filter(name__istartswith=query).values_list('name', flat=True)
    return JsonResponse(list(specializations), safe=False)

def list_doctors(request):
    location = request.GET.get('location')
    specialization = request.GET.get('specialization')
    
    doctors = Doctor.objects.filter(
        Q(location__name__iexact=location) & 
        Q(specialization__name__iexact=specialization)
    )
    
    return render(request, 'doctor_finder/list.html', {'doctors': doctors})

@login_required
def book_timeslot(request, doctor_id):
    doctor = Doctor.objects.get(id=doctor_id)
    if request.method == 'POST':
        date = request.POST.get('date')
        time = request.POST.get('time')
        phone = request.POST.get('phone')
        
        time_slot = TimeSlot.objects.get(doctor=doctor, date=date, start_time=time, is_booked=False)
        time_slot.is_booked = True
        time_slot.save()
        
        Booking.objects.create(
            patient=request.user,
            doctor=doctor,
            time_slot=time_slot,
            patient_phone=phone
        )
        
        return redirect('booking_success')
    
    available_slots = TimeSlot.objects.filter(doctor=doctor, is_booked=False)
    return render(request, 'doctor_finder/timeslot.html', {'doctor': doctor, 'available_slots': available_slots})

def booking_success(request):
    return render(request, 'doctor_finder/success.html')
