from django.core.management.base import BaseCommand
from doctor_finder.models import Doctor, Location, Specialization, TimeSlot, Booking

class Command(BaseCommand):
    help = 'Flush all data from doctor_finder models'

    def handle(self, *args, **kwargs):
        # Delete data in a specific order to avoid foreign key constraint issues
        Booking.objects.all().delete()
        TimeSlot.objects.all().delete()
        Doctor.objects.all().delete()
        Location.objects.all().delete()
        Specialization.objects.all().delete()

        self.stdout.write(self.style.SUCCESS('Successfully flushed all data in doctor_finder app'))
