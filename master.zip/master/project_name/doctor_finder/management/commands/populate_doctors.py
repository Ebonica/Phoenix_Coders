import random
from django.core.management.base import BaseCommand
from doctor_finder.models import Doctor, Location, Specialization
from django.contrib.auth import get_user_model

class Command(BaseCommand):
    help = 'Populate Doctor, Location, and Specialization tables with random values'

    def handle(self, *args, **kwargs):
        # # Flush all data
        # Doctor.objects.all().delete()
        # Location.objects.all().delete()
        # Specialization.objects.all().delete()

        # Random values to assign
        locations = [
            'Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem',
            'Tirunelveli', 'Tiruppur', 'Vellore', 'Erode', 'Thoothukkudi',
            'Dindigul', 'Thanjavur'
        ]
        specializations = [
            'Cardiologist', 'Dermatologist', 'Endocrinologist', 'Gastroenterologist',
            'Neurologist', 'Oncologist', 'Pediatrician', 'Psychiatrist', 'Surgeon',
            'Urologist', 'Ophthalmologist', 'Orthopedist'
        ]
        doctor_names = [
            'Dr. Arjun', 'Dr. Bala', 'Dr. Chitra', 'Dr. Divya', 'Dr. Eswar',
            'Dr. Farhan', 'Dr. Gayatri', 'Dr. Hari', 'Dr. Ishaan', 'Dr. Jaya'
        ]

        # Populate locations
        for location in locations:
            Location.objects.create(name=location)

        # Populate specializations
        for specialization in specializations:
            Specialization.objects.create(name=specialization)

        # Populate doctors with random values
        User = get_user_model()
        users = User.objects.all()[:len(doctor_names)]  # Assuming you have users created already

        for i, user in enumerate(users):
            doctor = Doctor.objects.create(
                user=user,
                doctor_name=random.choice(doctor_names),
                specialization=Specialization.objects.order_by('?').first(),
                location=Location.objects.order_by('?').first(),
                experience=random.randint(1, 40),
                consultation_fee=random.uniform(500, 5000),
            )
            self.stdout.write(self.style.SUCCESS(f'Doctor {doctor} created successfully.'))
