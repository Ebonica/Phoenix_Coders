from django.db import models
from django.conf import settings

class ChatHistory(models.Model):
    ROLE_CHOICES = [
        ('user', 'User'),
        ('assistant', 'Assistant'),
        ('summary', 'Summary'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    content = models.TextField()  # Chat content
    summary = models.TextField(null=True, blank=True)  # Optional summary field
    timestamp = models.DateTimeField(auto_now_add=True)  # Record time of the message

    def __str__(self):
        return f"{self.user.username} - {self.role}: {self.content[:50]}..."
