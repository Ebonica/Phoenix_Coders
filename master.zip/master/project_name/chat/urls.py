from django.urls import path
from . import views

urlpatterns = [
    path('chat/', views.chat_interface, name='chat'),
    path('send-message/', views.send_message, name='send_message'),
]