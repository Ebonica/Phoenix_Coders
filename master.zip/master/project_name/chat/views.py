import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from .models import ChatHistory
import ollama
from django.shortcuts import render

# Specify the AI model
desiredModel = 'llama3.2'

# Fetch the chat history from the database for the logged-in user
def fetch_chat_history(user):
    chat_history = ChatHistory.objects.filter(user=user).order_by('timestamp')
    return [{'role': entry.role, 'content': entry.content} for entry in chat_history]

# Handle the message sent to the AI chatbot
@login_required
@csrf_exempt
def send_message(request):
    if request.method == 'POST':
        # Extract the user input from the request
        data = json.loads(request.body)
        user_message = data.get('message')

        # Fetch previous chat history for the current user
        chat_history = fetch_chat_history(request.user)

        # Append the current user message to the chat history
        chat_history.append({'role': 'user', 'content': user_message})

        # Call the AI model with the entire conversation history
        response = ollama.chat(model=desiredModel, messages=chat_history)

        # Extract AI response content
        ai_response = response['message']['content']

        # Save the user's input and the AI's response in the database
        ChatHistory.objects.create(user=request.user, role='user', content=user_message)
        ChatHistory.objects.create(user=request.user, role='assistant', content=ai_response)

        # Return AI response to the frontend
        return JsonResponse({'response': ai_response})

    return JsonResponse({'error': 'Invalid request method'}, status=400)


@login_required
def chat_interface(request):
    return render(request, 'chat.html')