document.addEventListener('DOMContentLoaded', (event) => {
    const video = document.getElementById('video');
    const captureButton = document.getElementById('capture-button');
    const foodItemElement = document.getElementById('food-item');
    const nutrientsElement = document.getElementById('nutrients');
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function (stream) {
                video.srcObject = stream;
                video.play();
            })
            .catch(function (error) {
                console.error("Error accessing the camera: ", error);
                alert("Unable to access the camera. Please make sure you've granted permission and that your camera is not in use by another application.");
            });
    } else {
        alert("Sorry, camera capture is not supported by your browser");
    }

    captureButton.addEventListener('click', () => {
        captureButton.disabled = true;
        progressBar.style.width = '0%';
        progressText.textContent = 'Processing...';
        
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        const imageDataUrl = canvas.toDataURL('image/jpeg');

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/process_image/', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.setRequestHeader('X-CSRFToken', getCookie('csrftoken'));

        xhr.upload.onprogress = function(e) {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressBar.style.width = percentComplete + '%';
                progressText.textContent = `Uploading: ${Math.round(percentComplete)}%`;
            }
        };

        xhr.onload = function() {
            if (xhr.status === 200) {
                const data = JSON.parse(xhr.responseText);
                if (data.error) {
                    progressText.textContent = `Error: ${data.error}`;
                } else {
                    foodItemElement.textContent = data.food_item;
                    nutrientsElement.innerHTML = data.nutrients.replace(/\n/g, '<br>');
                    progressBar.style.width = '100%';
                    progressText.textContent = 'Processing complete';
                }
            } else {
                console.error('Error:', xhr.statusText);
                progressText.textContent = 'Error occurred';
            }
            captureButton.disabled = false;
        };

        xhr.onerror = function() {
            console.error('Request failed');
            progressText.textContent = 'Request failed';
            captureButton.disabled = false;
        };

        xhr.send(`image=${encodeURIComponent(imageDataUrl)}`);
    });

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
});