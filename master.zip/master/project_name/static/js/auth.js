let currentRole = 'doctor';

function switchRole(role) {
    currentRole = role;
    document.getElementById('doctorTab').classList.toggle('active', role === 'doctor');
    document.getElementById('userTab').classList.toggle('active', role === 'user');
    loadForm(role);
}

function loadForm(role) {
    const dynamicFields = document.getElementById('dynamicFields');
    dynamicFields.innerHTML = '';

    dynamicFields.innerHTML += `
        <input type="email" id="email" placeholder="Email" required>
        <input type="password" id="password" placeholder="Password" required>
    `;
}

document.addEventListener('DOMContentLoaded', () => {
    loadForm('doctor');
});

document.getElementById('authForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.textContent = '';

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const data = {
        email: email,
        password: password,
        role: currentRole
    };

    const url = window.location.pathname;

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = '/home/';  // Redirect to home page on success
        } else {
            errorMessage.textContent = data.message;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        errorMessage.textContent = 'An error occurred. Please try again.';
    });
});