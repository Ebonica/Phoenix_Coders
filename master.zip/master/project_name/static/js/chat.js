const chatBox = document.getElementById('chat-box');

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value;

    if (message.trim() !== '') {
        appendMessage('user', message);
        input.value = ''; // Clear input field after sending message

        // Send user message to the backend
        fetch('/chat/send-message/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': '{{ csrf_token }}'  // Ensure CSRF token is passed
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            if (data.response) {
                appendMessage('assistant', data.response);  // Display AI response
            } else {
                appendMessage('assistant', 'Error: No response from AI.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            appendMessage('assistant', 'Error sending message. Please try again.');
        });
    }
}

function appendMessage(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', role);
    messageDiv.innerText = content;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;  // Scroll to the bottom
}
